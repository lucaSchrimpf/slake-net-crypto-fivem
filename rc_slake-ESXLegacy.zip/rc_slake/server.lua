

RegisterServerEvent('rc_slake:getBalance')
AddEventHandler('rc_slake:getBalance', function()
    local xPlayer = ESX.GetPlayerFromId(source)

    TriggerClientEvent("rc_slake:openNUI", source,  xPlayer.getAccount('bank').money)

end)

RegisterServerEvent('rc_slake:changeBalance')
AddEventHandler('rc_slake:changeBalance', function(amount, type)
    
	
    local xPlayer = ESX.GetPlayerFromId(source)


    if type == "withdraw" then
        xPlayer.addAccountMoney('bank', amount);
    elseif type == "deposit"  then
        xPlayer.removeAccountMoney('bank', amount)
    end




    
end)