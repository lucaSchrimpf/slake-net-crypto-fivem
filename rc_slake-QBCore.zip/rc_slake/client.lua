
local QBCore = exports["qb-core"]:GetCoreObject()


RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = QBCore.Functions.GetPlayerData()
end)

RegisterCommand("slake", function()
	
	TriggerServerEvent("rc_slake:getBalance")

end)

RegisterNUICallback("exit", function() 
    SetDisplay(false) 
end)

RegisterNUICallback("action", function(data) 
    SetDisplay(false) 
	

	TriggerServerEvent("rc_slake:changeBalance", data.amount, data.type)

end)

function SetDisplay(bool, balance)
	display = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = bool,
        serverID = Config.serverID,
        balance = balance
    })
end



Citizen.CreateThread(function()
    while display do
        Citizen.Wait(0)
        -- https://runtime.fivem.net/doc/natives/#_0xFE99B66D079CF6BC
        --[[ 
            inputGroup -- integer , 
	        control --integer , 
            disable -- boolean 
        ]]
        DisableControlAction(0, 1, display) -- LookLeftRight
        DisableControlAction(0, 2, display) -- LookUpDown
        DisableControlAction(0, 142, display) -- MeleeAttackAlternate
        DisableControlAction(0, 18, display) -- Enter
        DisableControlAction(0, 322, display) -- ESC
        DisableControlAction(0, 106, display) -- VehicleMouseControlOverride
    end
end)



RegisterNetEvent('rc_slake:openNUI')
AddEventHandler('rc_slake:openNUI', function(balance)
	SetDisplay(true, balance)
    
end)