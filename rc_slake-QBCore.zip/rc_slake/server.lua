local QBCore = exports['qb-core']:GetCoreObject()


RegisterServerEvent('rc_slake:getBalance')
AddEventHandler('rc_slake:getBalance', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    TriggerClientEvent("rc_slake:openNUI", src, Player.PlayerData.money.bank)

end)


RegisterServerEvent('rc_slake:changeBalance')
AddEventHandler('rc_slake:changeBalance', function(amount, type)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
	

    if type == "withdraw" then
        Player.Functions.AddMoney("bank", amount, "Slake-Net Crypto - Withdraw")
    elseif type == "deposit" then
        Player.Functions.RemoveMoney('bank', amount)
    end




    
end)